# frozen_string_literal: true

# app/controllers/v2/items_controller.rb
class V2::TodosController < ApplicationController
  def index
    json_response(message: 'Hello there')
  end
end
